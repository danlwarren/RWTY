#' Analyze.rwty, the main interface for rwty analyses and plots.
#' 
#' This is the main user interface to rwty.  It allows users to chuck in arguments for
#' chains, burnin, window size, gens per tree, and "step", and returns an object that
#' contains sliding window and cumulative posterior probability plots, treespace plots,
#' and multi-chain diagnostic plots when multiple chains are provided.
#'
#' @param chains A list of rwty.trees objects. \code{chains}
#' @param burnin The number of trees to eliminate as burnin.  Default value is zero. \code{burnin}
#' @param window.size The length of window (in trees) for the sliding window plot.  If no value is provided, RWTY selects a number so that 20 windows are analyzed over the chain. \code{window.size}
#' @param gens.per.tree The number of generations per tree in the .t file.  If no value is provided, RWTY will attempt to determine the number of generations from the tree names.  \code{gens.per.tree}
#' @param treespace.points The number of trees to plot in the treespace plot. Default is 100 \code{treespace.points}
#' @param min.freq The minimum frequency for a node to be used for calculating discordance. Default is zero.  \code{min.freq}
#'
#' @return output A list of outputs from the analyze.single runs on each chain, as well as a compare.n run for all chains.  Eventually we will add more multi-chain analyses.
#'
#' @keywords keywords
#'
#' @export
#' 
#' @examples
#' data(fungus)
#' single <- analyze.rwty(run1, burnin=100, window.size=20, treespace.points=50, filename="Run1.pdf")
#' multi <- analyze.rwty(list(run1, run2), burnin=100, window.size=20, treespace.points=50, labels=c("Chain1", "Chain2"), filename="multi analysis.pdf")

analyze.rwty <- function(chains, burnin=0, window.size=NA, gens.per.tree=NA, treespace.points = 100, min.freq = 0, ...){
    
    # If a single rwty.trees object is passed, it goes to the analyze.single
    # function.  Otherwise it assumes that multiple rwty.trees objects
    # have been passed as a list.
    if(class(chains) == "rwty.trees" || length(chains) == 1){ # A single trees object or a list with only one such object
        if(class(chains) == "list"){chains <- chains[[1]]}
        if(is.na(window.size)){
            window.size = floor(length(chains[[1]])/20)
        }
        if(((length(chains[[1]]) - burnin)/window.size)  < 3){
            stop("Burnin or window size are too large to leave enough trees for analysis")
        }
        print("Analyzing single chain...")
        analyze.single(chains, burnin, window.size,
                       gens.per.tree, treespace.points, ...)
    }
    
    else{
        print("Analyzing multiple chains...")
        if(is.na(window.size)){
            window.size = floor(length(chains[[1]][[1]])/20)
        }
        if(((length(chains[[1]][[1]]) - burnin)/window.size)  < 3){
            stop("Burnin or window size are too large to leave enough trees for analysis")
        }
        analyze.multi(chains, burnin, window.size, gens.per.tree, treespace.points, min.freq=min.freq, ...)
    }
}